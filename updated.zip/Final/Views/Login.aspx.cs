﻿using System;
using System.Web.UI;

namespace Final.Views
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Your Page_Load logic here
        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            // Your login logic here
        }
    }
}
