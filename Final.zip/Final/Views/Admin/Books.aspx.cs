﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace Final.Views
{
    public partial class Books : System.Web.UI.Page
    {
        private readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\sharu\Documents\PROJECTASPDB.mdf;Integrated Security=True;Connect Timeout=30";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindAuthorsDropdown();
                BindCategoriesDropdown();
                BindBooksGrid();
            }
        }

        private void BindAuthorsDropdown()
        {
            string query = "SELECT AutId, AutName FROM AuthorTb1";
            DataTable dt = GetData(query);
            DropDownList2.DataSource = dt;
            DropDownList2.DataTextField = "AutName";
            DropDownList2.DataValueField = "AutId";
            DropDownList2.DataBind();
        }

        private void BindCategoriesDropdown()
        {
            string query = "SELECT Catid, CatName FROM categoryTb1";
            DataTable dt = GetData(query);
            DropDownList1.DataSource = dt;
            DropDownList1.DataTextField = "CatName";
            DropDownList1.DataValueField = "Catid";
            DropDownList1.DataBind();
        }

        private void BindBooksGrid()
        {
            string query = "SELECT BId, BName, BQty, BPrice FROM BookTb1";
            DataTable dt = GetData(query);
            GridView1.DataSource = dt;
            GridView1.DataKeyNames = new string[] { "BId" }; // Ensure DataKeyNames is set to primary key
            GridView1.DataBind();
        }

       protected void SaveBtn_Click(object sender, EventArgs e)
{
    try
    {
        string booksTitle = BooksTitle.Value;
        int booksAuthor = Convert.ToInt32(DropDownList2.SelectedValue);
        int booksCategory = Convert.ToInt32(DropDownList1.SelectedValue);
        int price = Convert.ToInt32(Price.Value);
        int quantity = Convert.ToInt32(Quantity.Value);

        string query = "INSERT INTO BookTb1 (BName, BAuthor, BCategory, BQty, BPrice) " +
                       "VALUES (@BName, @BAuthor, @BCategory, @BQty, @BPrice)";

        ExecuteNonQuery(query,
            "@BName", booksTitle,
            "@BAuthor", booksAuthor,
            "@BCategory", booksCategory,
            "@BQty", quantity,
            "@BPrice", price);

        BindBooksGrid(); // Rebind GridView after saving
        ClearFields();
    }
    catch (Exception ex)
    {
        ShowErrorMessage("Error saving book: " + ex.Message);
    }
}


        protected void UpdateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                int bookId = Convert.ToInt32(GridView1.SelectedDataKey.Value);
                string booksTitle = BooksTitle.Value;
                int booksAuthor = Convert.ToInt32(DropDownList2.SelectedValue);
                int booksCategory = Convert.ToInt32(DropDownList1.SelectedValue);
                int price = Convert.ToInt32(Price.Value);
                int quantity = Convert.ToInt32(Quantity.Value);

                string query = "UPDATE BookTb1 SET BName = @BName, BAuthor = @BAuthor, BCategory = @BCategory, BQty = @BQty, BPrice = @BPrice " +
                               "WHERE BId = @BId";

                ExecuteNonQuery(query,
                    "@BName", booksTitle,
                    "@BAuthor", booksAuthor,
                    "@BCategory", booksCategory,
                    "@BQty", quantity,
                    "@BPrice", price,
                    "@BId", bookId);

                BindBooksGrid(); 
                ClearFields();
            }
            catch (Exception ex)
            {
                ShowErrorMessage("Error updating book: " + ex.Message);
            }
        }

        protected void DeleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                int bookId = Convert.ToInt32(GridView1.SelectedDataKey.Value);

                string query = "DELETE FROM BookTb1 WHERE BId = @BId";

                ExecuteNonQuery(query,
                    "@BId", bookId);

                BindBooksGrid();
                ClearFields();
            }
            catch (Exception ex)
            {
                ShowErrorMessage("Error deleting book: " + ex.Message);
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            if (row != null)
            {
                int bookId = Convert.ToInt32(GridView1.DataKeys[row.RowIndex].Value);
                string query = "SELECT BName, BAuthor, BCategory, BQty, BPrice FROM BookTb1 WHERE BId = @BId";
                DataTable dt = GetData(query, "@BId", bookId);
                if (dt.Rows.Count > 0)
                {
                    BooksTitle.Value = dt.Rows[0]["BName"].ToString();
                    DropDownList2.SelectedValue = dt.Rows[0]["BAuthor"].ToString();
                    DropDownList1.SelectedValue = dt.Rows[0]["BCategory"].ToString();
                    Price.Value = dt.Rows[0]["BPrice"].ToString();
                    Quantity.Value = dt.Rows[0]["BQty"].ToString();
                }
            }
        }

        private DataTable GetData(string query, params object[] parameters)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    if (parameters != null && parameters.Length > 0)
                    {
                        for (int i = 0; i < parameters.Length; i += 2)
                        {
                            string paramName = parameters[i].ToString();
                            object paramValue = parameters[i + 1];
                            cmd.Parameters.AddWithValue(paramName, paramValue);
                        }
                    }

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        private void ExecuteNonQuery(string query, params object[] parameters)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    if (parameters != null && parameters.Length > 0)
                    {
                        for (int i = 0; i < parameters.Length; i += 2)
                        {
                            string paramName = parameters[i].ToString();
                            object paramValue = parameters[i + 1];
                            cmd.Parameters.AddWithValue(paramName, paramValue);
                        }
                    }

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void ClearFields()
        {
            BooksTitle.Value = string.Empty;
            DropDownList2.SelectedIndex = 0; 
            DropDownList1.SelectedIndex = 0;
            Price.Value = string.Empty;
            Quantity.Value = string.Empty;
        }

        private void ShowErrorMessage(string message)
        {
            ErrMsg.Text = message;
        }
    }
}
